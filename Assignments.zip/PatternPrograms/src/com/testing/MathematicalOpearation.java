package com.testing;

public class MathematicalOpearation {
	void SquareCube() {
		int n = 5;

		System.out.println("Square = " + (n * n));
		System.out.println("Cube = " + (n * n * n));
	}

	void AreaOfCircle() {
		double radius = 7;
		double area;

		area = 3.14 * (radius * radius);

		System.out.println("Area of Circle is " + area);
	}

	void AreaOfTriangle() {
		double base = 6;
		double height = 8;
		double area = (base * height) / 2;

		System.out.println("Area of Triangle is " + area);
	}

	void PerimeterOfRect() {
		int len = 10, wid = 5;

		int peri = 2 * (len + wid);
		System.out.println("Perimeter of Rectangle is " + peri);
	}

	void AbsoluteDiff() {
		int a = 14, b = 8;

		System.out.println("Absolute Difference  between two numbers is " + (a - b));
	}

	void AreaOfSpare() {
		double radius = 5;

		double area = 4 * 3.14 * radius * radius;
		System.out.println("Surface Arae Of spare is " + area);
	}

	public static void main(String[] args) {

		MathematicalOpearation math = new MathematicalOpearation();

		math.SquareCube();
		math.AreaOfCircle();
		math.AreaOfTriangle();
		math.PerimeterOfRect();
		math.AbsoluteDiff();
		math.AreaOfSpare();
	}
}
