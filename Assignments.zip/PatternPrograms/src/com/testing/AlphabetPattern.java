package com.testing;

import java.util.Iterator;

public class AlphabetPattern {
	public static void main(String[] args) {

		int n = 5;
		int count = 1;

		for (int i = 1; i <= n; i++) {

			for (int j = 1; j <= i; j++) {
				if (count < 10) {
					System.out.print("0");
				}
				System.out.print(count++ + " ");
			}
			System.out.println();
		}

		// Alphabet A pattern

		System.out.println();
		System.out.println();
		int a = 6;

		for (int i = 0; i < a; i++) {

			for (int k = 0; k < (a - 1) - i; k++) {
				System.out.print(" ");
			}
			for (int j = 0; j <= i; j++) {

				if (j == 0 || i == 0 || j == i || i == a / 2) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		// Alphabet B pattern

		System.out.println();
		System.out.println();

		int b = 7;

		for (int i = 0; i <= b - 1; i++) {

			for (int j = 0; j <= b - 1; j++) {

				if (i == 0 || j == 0 || i == b - 1 || j == b - 1 || i == b / 2) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}

		// Alphabet C pattern

		System.out.println();
		System.out.println();

		int c = 6;

		for (int i = 0; i < c; i++) {

			for (int j = 0; j < c; j++) {

				if (i == 0 || j == 0 || i == c - 1)

					System.out.print("*");
			}
			System.out.println();
		}

		// Alphabet E pattern

		System.out.println();
		System.out.println();

		int e = 7;

		for (int i = 0; i < e; i++) {

			for (int j = 0; j < e; j++) {

				if (i == 0 || j == 0 || i == e - 1 || i == e / 2)

					System.out.print("*");
			}
			System.out.println();
		}

		// Alphabet F pattern

		System.out.println();
		System.out.println();

		int f = 6;

		for (int i = 0; i <= f; i++) {

			for (int j = 0; j < f; j++) {

				if (i == 0 || j == f - 1 || i == f / 2) {

					System.out.print("*");
				}
			}
			System.out.println();
		}

		// Alphabet H pattern

		System.out.println();
		System.out.println();

		int h = 7;

		for (int i = 0; i < h; i++) {

			for (int j = 0; j < h; j++) {

				if (j == 0 || j == h - 1 || i == h / 2) {

					System.out.print(" *");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		// Alphabet I pattern

		System.out.println();
		System.out.println();

		int I = 7;

		for (int i = 0; i < I; i++) {

			for (int j = 0; j < I; j++) {

				if (i == 0 || i == I - 1 || j == I / 2) {

					System.out.print(" *");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		// Alphabet L pattern

		System.out.println();
		System.out.println();

		int l = 6;

		for (int i = 0; i < l; i++) {

			for (int j = 0; j < l; j++) {

				if (j == 0 || i == l - 1) {
					System.out.print("*");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		// Alphabet N pattern

		System.out.println();
		System.out.println();

		int N = 7;

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (j == 0 || j == N - 1 || i == j) {

					System.out.print(" *");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

		// Alphabet T pattern

		System.out.println();
		System.out.println();

		int t = 5;

		for (int i = 0; i < t; i++) {

			for (int j = 0; j < t; j++) {

				if (i == 0 || j == t / 2) {
					System.out.print(" *");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}
	}
}
