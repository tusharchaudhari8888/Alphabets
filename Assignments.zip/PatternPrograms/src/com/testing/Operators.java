package com.testing;

public class Operators {

	void Addition() {
		int a = 4;
		int b = 6;

		int c = a + b;

		System.out.println("Addition is : " + c);

	}

	void Modulus() {
		int a = 27;
		int b = 4;

		int remainder = a % b;

		System.out.println("Remainder is : " + remainder);
	}

	void Compare() {
		int x = 25;
		int y = 30;
		int z;

		if (x > y) {
			System.out.println(x + " is larger");
		} else {
			System.out.println(y + " is larger");
		}

	}
	
	void Boolean() {
		int x=15, y=18;
		if (x>10 && y<20) {
			System.out.println("Bothe condition are true");
		}
	}

	void FloatSum() {
		double x = 5.5;
		double y = 3.3;
		System.out.println("Sum of Floating number is " + (x + y));
	}

	void FloatModulus() {
		double a = 5.5;
		double b = 2.3;
		System.out.println("Modulud  of Floating number is " + (a % b));
	}

	void Average() {
		int a = 10, b = 20, c = 30;
		int avg;
		avg = (a + b + c) / 3;
		System.out.println("Average = " + avg);
	}

	void EvenOdd() {
		int n = 9;
		if (n % 2 == 0) {
			System.out.println(n + " is even number");
		}
		System.out.println(n + " is odd number");
	}
	
	void LargestThreeNumber() {
		int a= 12, b= 7 , c = 15;
		
		if (a<b) {
			System.out.println(a + " is largest");
		} else if(a<c){
			System.out.println(c + " is largest");
		}else if(b>c) {
			System.out.println(b + " is largest");
		}else {
			System.out.println(c + " is largest");
		}
	}

	public static void main(String[] args) {

		Operators op = new Operators();
		op.Addition();
		op.Modulus();
		op.Compare();
		op.Boolean();
		op.FloatSum();
		op.FloatModulus();
		op.Average();
		op.EvenOdd();
		op.LargestThreeNumber();

	}
}
