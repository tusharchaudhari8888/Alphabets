package com.testing;

public class Swap {

	void swappingTwoNumbers() {
		int a = 10;
		int b = 20;
		
		a = a + b;    // 10 + 20 = 30
		b = a - b;    // 30 - 20 = 10
		a = a - b;    // 30 -10 = 20
		
		System.out.println("Swapping : a = " + a + ", b = " + b);
		
	}
	
	public static void main(String[] args) {
		
		Swap sw = new Swap();
		sw.swappingTwoNumbers();
	}
}
